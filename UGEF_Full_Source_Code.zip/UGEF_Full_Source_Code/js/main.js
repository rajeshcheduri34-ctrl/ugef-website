document.getElementById('year').textContent=new Date().getFullYear();
const menu=document.getElementById('menu'),links=document.getElementById('navlinks');
menu.addEventListener('click',()=>links.classList.toggle('open'));
links.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));
document.getElementById('contactForm').addEventListener('submit',e=>{
 e.preventDefault();const d=new FormData(e.target);
 const subject=encodeURIComponent(d.get('subject')||'Website enquiry for UGEF');
 const body=encodeURIComponent('Name: '+d.get('name')+'\nEmail: '+d.get('email')+'\n\n'+d.get('message'));
 document.getElementById('formNote').textContent='Your email application should open with the enquiry prepared. Add the organisation’s official email address before launch.';
 window.location.href='mailto:?subject='+subject+'&body='+body;
});
