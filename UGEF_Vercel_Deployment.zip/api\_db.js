const fs = require('fs');
const path = require('path');

const KV_URL = process.env.KV_REST_API_URL;
const KV_TOKEN = process.env.KV_REST_API_TOKEN;

// Local storage fallback for local development or zero-config Vercel previews
const LOCAL_FILE = process.env.VERCEL
  ? path.join('/tmp', 'ugef_contacts.json')
  : path.join(__dirname, '..', 'ugef_contacts.json');

async function kvCommand(...args) {
  const res = await fetch(KV_URL, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${KV_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(args)
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.result;
}

function readLocalContacts() {
  try {
    if (fs.existsSync(LOCAL_FILE)) {
      const data = fs.readFileSync(LOCAL_FILE, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading local contacts:', err);
  }
  return [];
}

function writeLocalContacts(contacts) {
  try {
    fs.writeFileSync(LOCAL_FILE, JSON.stringify(contacts, null, 2), 'utf8');
  } catch (err) {
    console.error('Error writing local contacts:', err);
  }
}

async function getAllContacts() {
  if (KV_URL && KV_TOKEN) {
    try {
      const result = await kvCommand('HGETALL', 'ugef:contacts');
      if (!result) return [];
      const list = Object.values(result).map(str => {
        try { return JSON.parse(str); } catch { return null; }
      }).filter(Boolean);
      list.sort((a, b) => (b.id || 0) - (a.id || 0));
      return list;
    } catch (err) {
      console.error('KV fetch error, falling back to local file:', err);
    }
  }
  const list = readLocalContacts();
  list.sort((a, b) => (b.id || 0) - (a.id || 0));
  return list;
}

async function addContact({ name, email, subject, message }) {
  const createdAt = new Date().toISOString();

  if (KV_URL && KV_TOKEN) {
    try {
      const id = await kvCommand('INCR', 'ugef:contact_seq');
      const item = { id, name, email, subject, message, created_at: createdAt };
      await kvCommand('HSET', 'ugef:contacts', String(id), JSON.stringify(item));
      return item;
    } catch (err) {
      console.error('KV add error, falling back to local file:', err);
    }
  }

  const list = readLocalContacts();
  const maxId = list.reduce((m, item) => Math.max(m, item.id || 0), 0);
  const id = maxId + 1;
  const item = { id, name, email, subject, message, created_at: createdAt };
  list.push(item);
  writeLocalContacts(list);
  return item;
}

async function deleteContact(id) {
  const numId = parseInt(id, 10);
  if (!numId) return false;

  if (KV_URL && KV_TOKEN) {
    try {
      await kvCommand('HDEL', 'ugef:contacts', String(numId));
      return true;
    } catch (err) {
      console.error('KV delete error, falling back to local file:', err);
    }
  }

  const list = readLocalContacts();
  const filtered = list.filter(item => item.id !== numId);
  writeLocalContacts(filtered);
  return true;
}

async function getStats() {
  const list = await getAllContacts();
  return { total: list.length };
}

module.exports = {
  getAllContacts,
  addContact,
  deleteContact,
  getStats
};
