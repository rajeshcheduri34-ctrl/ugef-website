document.getElementById('year').textContent = new Date().getFullYear();

const menu = document.getElementById('menu');
const links = document.getElementById('navlinks');
if (menu && links) {
  menu.addEventListener('click', () => links.classList.toggle('open'));
  links.querySelectorAll('a').forEach(a => a.addEventListener('click', () => links.classList.remove('open')));
}

const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    const alertBox = document.getElementById('formAlert');
    const originalText = btn.textContent;

    const formData = new FormData(contactForm);
    const data = {
      name: (formData.get('name') || '').trim(),
      email: (formData.get('email') || '').trim(),
      subject: (formData.get('subject') || '').trim(),
      message: (formData.get('message') || '').trim()
    };

    try {
      btn.disabled = true;
      btn.textContent = 'Submitting...';
      if (alertBox) {
        alertBox.style.display = 'none';
      }

      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });

      const result = await res.json();

      if (res.ok && result.success) {
        if (alertBox) {
          alertBox.style.display = 'block';
          alertBox.style.background = '#dcfce7';
          alertBox.style.color = '#14532d';
          alertBox.style.border = '1px solid #86efac';
          alertBox.innerHTML = `✓ <strong>Thank you, ${escapeHtml(data.name)}!</strong> Your message has been saved in our database. You can view it in the <a href="admin.html" style="text-decoration:underline;color:#14532d;font-weight:700;">Admin Dashboard</a>.`;
        }
        contactForm.reset();
      } else {
        throw new Error(result.error || 'Failed to submit form');
      }
    } catch (err) {
      if (alertBox) {
        alertBox.style.display = 'block';
        alertBox.style.background = '#fee2e2';
        alertBox.style.color = '#991b1b';
        alertBox.style.border = '1px solid #fca5a5';
        alertBox.textContent = '⚠ ' + err.message;
      }
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
