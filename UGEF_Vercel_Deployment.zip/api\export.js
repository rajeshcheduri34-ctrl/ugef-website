const db = require('./_db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');

  try {
    const rows = await db.getAllContacts();
    let csv = 'ID,Name,Email,Subject,Message,Created At\r\n';
    for (const row of rows) {
      const escapeCsv = (str) => `"${(str || '').replace(/"/g, '""')}"`;
      csv += `${row.id},${escapeCsv(row.name)},${escapeCsv(row.email)},${escapeCsv(row.subject)},${escapeCsv(row.message)},${escapeCsv(row.created_at)}\r\n`;
    }

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="ugef_contacts.csv"');
    return res.status(200).send(csv);
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
};
