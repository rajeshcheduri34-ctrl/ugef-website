const db = require('./_db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  // Handle DELETE (e.g. /api/contacts/:id rewritten to /api/contact?id=...)
  if (req.method === 'DELETE') {
    const id = req.query ? req.query.id : null;
    if (!id) {
      return res.status(400).json({ success: false, error: 'ID is required' });
    }
    const success = await db.deleteContact(id);
    return res.status(200).json({ success, message: 'Deleted successfully', id });
  }

  // Handle GET (all contacts)
  if (req.method === 'GET') {
    try {
      const contacts = await db.getAllContacts();
      return res.status(200).json({
        success: true,
        count: contacts.length,
        data: contacts
      });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }

  // Handle POST (new submission)
  if (req.method === 'POST') {
    try {
      let body = req.body;
      if (typeof body === 'string') {
        try {
          body = JSON.parse(body);
        } catch {
          body = {};
        }
      }
      body = body || {};

      const name = (body.name || '').trim();
      const email = (body.email || '').trim();
      const subject = (body.subject || '').trim();
      const message = (body.message || '').trim();

      if (!name || !email || !message) {
        return res.status(400).json({
          success: false,
          error: 'Name, email, and message are required fields.'
        });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({
          success: false,
          error: 'Please provide a valid email address.'
        });
      }

      const contact = await db.addContact({ name, email, subject, message });

      return res.status(201).json({
        success: true,
        message: 'Thank you! Your message has been saved successfully.',
        id: contact.id,
        data: contact
      });
    } catch (err) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
