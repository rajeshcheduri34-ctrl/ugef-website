const db = require('./_db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  try {
    const stats = await db.getStats();
    return res.status(200).json({ success: true, total: stats.total });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
};
